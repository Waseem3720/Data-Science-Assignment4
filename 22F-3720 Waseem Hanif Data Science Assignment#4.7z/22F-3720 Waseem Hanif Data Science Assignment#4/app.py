# app.py - Enhanced UI
import streamlit as st
import joblib
import pickle
import numpy as np
import pandas as pd
import librosa
import soundfile as sf
import tensorflow as tf
import os
import io
import sys
import warnings
import time # To simulate processing time if needed

# =============================================
# SET PAGE CONFIG - MUST BE FIRST STREAMLIT COMMAND
# =============================================
st.set_page_config(
    page_title="AI Prediction Hub",
    page_icon="🤖", # Added a relevant icon
    layout="wide",
    initial_sidebar_state="expanded" # Keep sidebar open initially
)

# --- Suppress specific warnings ---
warnings.filterwarnings("ignore", category=UserWarning, module='sklearn.base')
warnings.filterwarnings("ignore", category=UserWarning, module='sklearn.linear_model._logistic')
warnings.filterwarnings("ignore", message="X does not have valid feature names")
# Suppress TF Lite warning if it appears (can happen depending on TF version)
warnings.filterwarnings("ignore", message=".*Check whether the TFLite Optimizing Converter is enabled.*")


# =============================================
# CSS Styling
# =============================================
# Inject custom CSS for styling elements
st.markdown("""
<style>
    /* Main title style */
    .stApp > header {
        background-color: transparent;
    }
    h1 {
        color: #1E90FF; /* Dodger Blue */
        text-align: center;
    }
    /* Sidebar styling */
    .css-1d391kg { /* Sidebar main class (might change with Streamlit versions) */
        background-color: #f0f2f6; /* Light gray background */
    }
    /* Button styling */
    .stButton>button {
        color: #ffffff; /* White text */
        background-color: #1E90FF; /* Dodger Blue */
        border: none;
        padding: 10px 24px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 16px;
        margin: 4px 2px;
        cursor: pointer;
        border-radius: 16px; /* Rounded corners */
        transition-duration: 0.4s;
        width: 100%; /* Make buttons fill sidebar width */
        box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
    }
    .stButton>button:hover {
        background-color: #4682B4; /* Steel Blue on hover */
        color: white;
        box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);
    }
    /* Style containers for results */
    .result-container {
        padding: 20px;
        border-radius: 10px;
        border: 1px solid #ddd;
        background-color: #ffffff;
        margin-bottom: 20px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    /* Style for success/error messages within results */
     .stSuccess {
        border: 1px solid #28a745;
        border-left-width: 5px;
        padding: 10px;
        border-radius: 5px;
        background-color: #e9f7ef;
    }
    .stError {
        border: 1px solid #dc3545;
        border-left-width: 5px;
        padding: 10px;
        border-radius: 5px;
        background-color: #fdecea;
    }
    .stInfo {
         border: 1px solid #17a2b8;
         border-left-width: 5px;
         padding: 10px;
         border-radius: 5px;
         background-color: #e7f6f8;
    }
    /* Center metric labels */
     .stMetric > div:nth-child(1) { /* Target the label div */
        text-align: center;
        font-weight: bold;
    }
    /* Center metric values */
    .stMetric > div:nth-child(2) { /* Target the value div */
       text-align: center;
       font-size: 1.5rem; /* Adjust size */
    }
    /* Style expander headers */
    .st-expander > summary {
        font-size: 1.1rem;
        font-weight: bold;
        color: #333;
    }

</style>
""", unsafe_allow_html=True)

# =============================================
# Configuration and Artifact Loading (Functions remain the same)
# =============================================
PART1_ARTIFACTS_DIR = "part1_artifacts"
PART2_ARTIFACTS_DIR = "part2_artifacts"

# --- Define Necessary Functions from Part 1 ---
@st.cache_data
def extract_features_p1_app(audio_data, sample_rate, n_mfcc=40, max_len_sec=5):
    """Extracts features (MFCC) for app, matching Part 1."""
    if audio_data is None or sample_rate is None or audio_data.size == 0: return None
    target_len_samples = int(max_len_sec * sample_rate)
    current_len = len(audio_data)
    if current_len > target_len_samples: audio_data = audio_data[:target_len_samples]
    elif current_len < target_len_samples:
        pad_width = target_len_samples - current_len
        if pad_width >= 0: audio_data = np.pad(audio_data, (0, pad_width), 'constant')
    if audio_data.size == 0: return None
    try:
        mfccs = librosa.feature.mfcc(y=audio_data.astype(np.float32), sr=sample_rate, n_mfcc=n_mfcc)
        if not np.isfinite(mfccs).all(): return None
        features = np.mean(mfccs.T, axis=0)
        return None if np.isnan(features).any() else features
    except Exception as e:
        print(f"Feature extraction error: {e}") # Log error instead of st.error here
        return None

# --- Load Artifacts with Streamlit Caching ---
@st.cache_resource
def load_part1_config():
    config_path = os.path.join(PART1_ARTIFACTS_DIR, 'part1_config.pkl')
    try:
        with open(config_path, 'rb') as f: return pickle.load(f)
    except Exception as e:
        print(f"CRITICAL ERROR: Part 1 config file not found or failed to load: {e} at {config_path}")
        return None

@st.cache_resource
def load_part1_scaler():
    scaler_path = os.path.join(PART1_ARTIFACTS_DIR, "scaler_p1.joblib")
    try: return joblib.load(scaler_path)
    except Exception as e:
        print(f"CRITICAL ERROR: Part 1 scaler not found or failed to load: {e} at {scaler_path}")
        return None

@st.cache_resource
def load_part1_sklearn_model(model_filename):
    model_path = os.path.join(PART1_ARTIFACTS_DIR, model_filename)
    try: return joblib.load(model_path)
    except Exception as e:
        print(f"ERROR: Part 1 model not found or failed to load: {e} at {model_path}")
        return None

@st.cache_resource
def load_part1_dnn_model():
    model_path = os.path.join(PART1_ARTIFACTS_DIR, "dnn_model_p1.keras")
    if not os.path.exists(model_path):
        print(f"WARNING: Part 1 DNN model file not found at {model_path}.")
        return None
    try: return tf.keras.models.load_model(model_path)
    except Exception as e:
        print(f"ERROR: Loading Part 1 DNN model failed: {e} at {model_path}")
        return None

@st.cache_resource
def load_part2_config():
    config_path = os.path.join(PART2_ARTIFACTS_DIR, 'part2_config.pkl')
    try:
        with open(config_path, 'rb') as f: return pickle.load(f)
    except Exception as e:
        print(f"CRITICAL ERROR: Part 2 config file not found or failed to load: {e} at {config_path}")
        return None

@st.cache_resource
def load_part2_vectorizer():
    vectorizer_path = os.path.join(PART2_ARTIFACTS_DIR, "vectorizer_p2.joblib")
    try: return joblib.load(vectorizer_path)
    except Exception as e:
        print(f"CRITICAL ERROR: Part 2 vectorizer not found or failed to load: {e} at {vectorizer_path}")
        return None

@st.cache_resource
def load_part2_sklearn_model(model_filename):
    model_path = os.path.join(PART2_ARTIFACTS_DIR, model_filename)
    try: return joblib.load(model_path)
    except Exception as e:
        print(f"ERROR: Part 2 model not found or failed to load: {e} at {model_path}")
        return None

@st.cache_resource
def load_part2_dnn_model():
    model_path = os.path.join(PART2_ARTIFACTS_DIR, "dnn_model_p2.keras")
    if not os.path.exists(model_path):
        print(f"WARNING: Part 2 DNN model file not found at {model_path}. DNN prediction will be unavailable.")
        return None
    try: return tf.keras.models.load_model(model_path)
    except Exception as e:
        print(f"ERROR: Loading Part 2 DNN model failed: {e} at {model_path}")
        return None

# --- Attempt to Load Artifacts and Handle Critical Errors ---
critical_load_error = False
error_messages = []

p1_config = load_part1_config()
if p1_config is None:
    critical_load_error = True; error_messages.append("Part 1 configuration")
else:
    N_MFCC_APP = p1_config.get('N_MFCC', 40)
    MAX_AUDIO_LEN_APP = p1_config.get('MAX_AUDIO_LEN_SECONDS', 5)

scaler_p1 = load_part1_scaler()
if scaler_p1 is None: critical_load_error = True; error_messages.append("Part 1 scaler")

p2_config = load_part2_config()
if p2_config is None:
    critical_load_error = True; error_messages.append("Part 2 configuration")
else:
    label_columns_p2 = p2_config.get('label_columns', [])
    if not label_columns_p2: critical_load_error = True; error_messages.append("Part 2 label columns")

vectorizer_p2 = load_part2_vectorizer()
if vectorizer_p2 is None: critical_load_error = True; error_messages.append("Part 2 vectorizer")

# If critical artifacts failed, display errors and stop
if critical_load_error:
    st.error("🚨 Critical Error Loading Model Artifacts!")
    st.error("The application cannot proceed because the following essential file(s) could not be loaded:")
    for item in error_messages:
        st.markdown(f"- **{item}**")
    st.error("Please ensure the training scripts (`part1_deepfake_detection.ipynb` and `part2_defect_prediction.ipynb`) were run successfully and generated the artifacts in the correct directories (`part1_artifacts`, `part2_artifacts`).")
    st.stop() # Stop the script execution

# Define model filenames
PART1_MODEL_FILES = {
    "SVM": "svm_p1.joblib",
    "Logistic Regression": "logistic_regression_p1.joblib",
    "DNN": "dnn_model_p1.keras"
}
PART2_MODEL_FILES = {
    "Logistic Regression": "logistic_regression_p2.joblib",
    "SVM (LinearSVC)": "svm_linearsvc_p2.joblib",
    "Perceptron (Batch)": "perceptron_batch_p2.joblib",
    "DNN": "dnn_model_p2.keras"
}

# Load DNN models now (handle errors individually later if needed)
part1_dnn_model = load_part1_dnn_model()
part2_dnn_model = load_part2_dnn_model()

# Create available model lists, excluding DNN if loading failed
part1_model_options = list(PART1_MODEL_FILES.keys())
if part1_dnn_model is None and "DNN" in part1_model_options:
     part1_model_options.remove("DNN")

part2_model_options = list(PART2_MODEL_FILES.keys())
if part2_dnn_model is None and "DNN" in part2_model_options:
     part2_model_options.remove("DNN")

# =============================================
# Streamlit App UI Setup
# =============================================

# --- Sidebar ---
with st.sidebar:
    st.image("https://streamlit.io/images/brand/streamlit-logo-secondary-colormark-darktext.svg", width=200) # Example logo
    st.header("⚙️ Controls")
    st.markdown("Configure your predictions here.")

    st.divider()

    # Part 1 Controls
    st.subheader("🎙️ Audio Deepfake Detection")
    uploaded_file = st.file_uploader("Upload Audio (.wav, .flac, .mp3)", type=["wav", "flac", "mp3"], key="p1_uploader")
    selected_model_p1 = st.selectbox("Select Audio Model:", part1_model_options, key="p1_model_select")
    predict_button_p1 = st.button("🎧 Predict Audio Type", key="p1_predict")
    if part1_dnn_model is None and selected_model_p1 == "DNN":
         st.warning("Part 1 DNN model is unavailable.")

    st.divider()

    # Part 2 Controls
    st.subheader("🐞 Software Defect Prediction")
    report_text = st.text_area("Enter Defect Report Text:", height=150, key="p2_text_area")
    selected_model_p2 = st.selectbox("Select Defect Model:", part2_model_options, key="p2_model_select")
    predict_button_p2 = st.button("🔍 Predict Defect Types", key="p2_predict")
    if part2_dnn_model is None and selected_model_p2 == "DNN":
         st.warning("Part 2 DNN model is unavailable.")

# --- Main Area ---
st.title("🤖 AI Prediction Hub")
st.markdown("Use the sidebar controls to upload data or enter text and select models for prediction.")

st.divider()

# Create columns for results display
col1, col2 = st.columns(2)

# --- Part 1 Results Area ---
with col1:
    st.header("🎙️ Audio Results")
    part1_results_container = st.container(border=True) # Use border=True for built-in container styling
    with part1_results_container:
        if predict_button_p1 and uploaded_file is not None:
            st.markdown("---") # Separator within the container
            st.info("⏳ Processing audio...")
            progress_bar_p1 = st.progress(0, text="Starting...")
            try:
                audio_bytes = uploaded_file.getvalue()
                audio_data, sample_rate = sf.read(io.BytesIO(audio_bytes))
                progress_bar_p1.progress(10, text="Audio loaded...")
                if audio_data.ndim > 1: audio_data = np.mean(audio_data, axis=1) # Convert to mono

                features = extract_features_p1_app(audio_data, sample_rate, N_MFCC_APP, MAX_AUDIO_LEN_APP)
                progress_bar_p1.progress(40, text="Features extracted...")

                if features is not None:
                    features_reshaped = features.reshape(1, -1)
                    features_scaled = scaler_p1.transform(features_reshaped) # Use loaded scaler_p1
                    progress_bar_p1.progress(60, text="Features scaled...")

                    model_p1 = None
                    model_key_p1 = selected_model_p1
                    if model_key_p1 == "DNN":
                        model_p1 = part1_dnn_model # Use pre-loaded model
                    elif model_key_p1 in PART1_MODEL_FILES:
                        model_p1 = load_part1_sklearn_model(PART1_MODEL_FILES[model_key_p1])

                    if model_p1 is not None:
                        prediction = -1
                        probability = -1.0
                        time.sleep(0.5) # Simulate prediction time
                        if model_key_p1 == "DNN":
                            proba_deepfake = model_p1.predict(features_scaled, verbose=0).flatten()[0]
                            prediction = 1 if proba_deepfake > 0.5 else 0
                            probability = proba_deepfake * 100 # Display as percentage
                        elif hasattr(model_p1, "predict_proba"):
                            proba_all = model_p1.predict_proba(features_scaled)[0]
                            prediction = np.argmax(proba_all)
                            probability = proba_all[1] * 100 # Probability of Deepfake
                        else: # Perceptron might not have probabilities
                            prediction = model_p1.predict(features_scaled)[0]
                            probability = np.nan # Mark probability as unavailable

                        progress_bar_p1.progress(90, text="Prediction generated...")

                        # Display results using st.metric and clear success/error
                        pred_label = "Deepfake" if prediction == 1 else "Bonafide"
                        pred_delta = f"{probability:.1f}% Confidence (Deepfake)" if not np.isnan(probability) else "Confidence N/A"
                        pred_delta_color = "inverse" if prediction == 1 else "normal" # Red for deepfake? Or use 'off'

                        if prediction == 1:
                            st.metric(label="Prediction", value="🚨 Deepfake", delta=pred_delta, delta_color=pred_delta_color)
                            st.error("Analysis indicates potential deepfake audio.")
                        elif prediction == 0:
                            st.metric(label="Prediction", value="✅ Bonafide", delta=pred_delta, delta_color=pred_delta_color)
                            st.success("Analysis indicates genuine audio.")
                        else:
                            st.metric(label="Prediction", value="❓ Unknown", delta="Could not determine")
                            st.warning("Prediction could not be determined.")

                        progress_bar_p1.progress(100, text="Done!")
                        time.sleep(0.5)
                        progress_bar_p1.empty() # Clear the progress bar

                    else:
                        st.error(f"Could not load the selected model: {model_key_p1}.")
                        progress_bar_p1.empty()
                else:
                    st.error("Could not extract valid features from the uploaded audio file.")
                    progress_bar_p1.empty()
            except Exception as e:
                st.error(f"An error occurred during audio processing: {e}")
                st.exception(e) # Optionally show traceback for debugging
                if 'progress_bar_p1' in locals(): progress_bar_p1.empty()

        elif predict_button_p1 and uploaded_file is None:
            st.warning("Please upload an audio file using the sidebar.")
        else:
            st.info("Upload an audio file and click 'Predict Audio Type' in the sidebar to see results here.")


# --- Part 2 Results Area ---
with col2:
    st.header("🐞 Defect Results")
    part2_results_container = st.container(border=True)
    with part2_results_container:
        if predict_button_p2 and report_text:
            st.markdown("---")
            st.info("⏳ Processing text...")
            progress_bar_p2 = st.progress(0, text="Starting...")
            try:
                text_vectorized = vectorizer_p2.transform([report_text]) # Use loaded vectorizer_p2
                progress_bar_p2.progress(40, text="Text vectorized...")

                model_p2 = None
                model_key_p2 = selected_model_p2
                if model_key_p2 == "DNN":
                     model_p2 = part2_dnn_model # Use pre-loaded model
                     if model_p2 is None: # Double check if DNN failed load earlier
                         st.error("Part 2 DNN model is unavailable.")
                         st.stop()
                elif model_key_p2 in PART2_MODEL_FILES:
                     model_p2 = load_part2_sklearn_model(PART2_MODEL_FILES[model_key_p2])
                else: # Should not happen if selectbox is populated correctly
                    st.error("Invalid model selection.")
                    st.stop()

                if model_p2 is not None:
                    predictions_binary = None; predictions_scores = None
                    time.sleep(0.5) # Simulate prediction time
                    if model_key_p2 == "DNN":
                         # Ensure input is dense for Keras DNN
                         text_dense = text_vectorized.toarray() if hasattr(text_vectorized, 'toarray') else text_vectorized
                         predictions_scores = model_p2.predict(text_dense, verbose=0)[0]
                         predictions_binary = (predictions_scores > 0.5).astype(int)
                    elif hasattr(model_p2, "decision_function"):
                         # Use decision_function for scores (better for ranking than predict_proba in OvR)
                         predictions_scores = model_p2.decision_function(text_vectorized)[0]
                         predictions_binary = model_p2.predict(text_vectorized)[0]
                    else: # Perceptron
                         predictions_binary = model_p2.predict(text_vectorized)[0]
                         predictions_scores = None # No reliable scores

                    progress_bar_p2.progress(90, text="Prediction generated...")

                    predicted_labels = [label_columns_p2[i] for i, pred in enumerate(predictions_binary) if pred == 1]

                    st.subheader("Predicted Defect Types:")
                    if predicted_labels:
                        # Display labels more visually
                        tags_html = "".join([f'<span style="background-color: #FFDDC1; color: #D9534F; border-radius: 5px; padding: 3px 8px; margin: 2px; display: inline-block; font-weight: bold;">{label.replace("type_", "").replace("_", " ").title()}</span>' for label in predicted_labels])
                        st.markdown(tags_html, unsafe_allow_html=True)
                        st.success("Identified potential defect categories based on the report.")
                    else:
                        st.info("No specific defect types predicted with high confidence by this model.")

                    # Show scores in an expander
                    with st.expander("Show Confidence Scores"):
                        if predictions_scores is not None:
                             scores_df = pd.DataFrame({'Label': label_columns_p2, 'Score': predictions_scores})
                             scores_df = scores_df.sort_values(by='Score', ascending=False) # Sort by score

                             # Convert scores to pseudo-probabilities if not DNN
                             if model_key_p2 != "DNN":
                                  scores_df['Pseudo-Probability (Sigmoid)'] = 1 / (1 + np.exp(-scores_df['Score']))
                                  st.dataframe(scores_df[['Label', 'Pseudo-Probability (Sigmoid)']].round(4), use_container_width=True)
                             else:
                                  st.dataframe(scores_df[['Label', 'Score']].rename(columns={'Score': 'Probability'}).round(4), use_container_width=True)
                        else:
                             st.write("Confidence scores not available for the Perceptron model.")

                    progress_bar_p2.progress(100, text="Done!")
                    time.sleep(0.5)
                    progress_bar_p2.empty() # Clear the progress bar

                else:
                    st.error(f"Could not load the selected model: {model_key_p2}.")
                    progress_bar_p2.empty()
            except Exception as e:
                st.error(f"An error occurred during text processing: {e}")
                st.exception(e) # Show traceback for debugging
                if 'progress_bar_p2' in locals(): progress_bar_p2.empty()

        elif predict_button_p2 and not report_text:
            st.warning("Please enter text in the defect report area in the sidebar.")
        else:
            st.info("Enter defect report text and click 'Predict Defect Types' in the sidebar to see results here.")